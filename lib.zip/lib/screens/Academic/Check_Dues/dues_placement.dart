// import 'package:fusion/models/academic.dart';
import 'package:flutter/material.dart';
// import 'package:fusion/Components/appBar.dart';
// import 'package:fusion/Components/side_drawer.dart';

class PlaccementDues extends StatefulWidget {
  @override
  _PlaccementDuesState createState() => _PlaccementDuesState();
}

class _PlaccementDuesState extends State<PlaccementDues> {
  @override
  Widget build(BuildContext context) {
    // final AcademicData data =
    //     ModalRoute.of(context)!.settings.arguments as AcademicData;
    return Scaffold(
      body: Container(
        alignment: Alignment.center,
        padding: EdgeInsets.all(16),
        child: Text(
          'work in progress',
        ),
      ),
    );
  }
}
