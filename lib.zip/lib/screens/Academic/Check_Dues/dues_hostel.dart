// import 'package:fusion/models/academic.dart';
import 'package:flutter/material.dart';
// import 'package:fusion/Components/appBar.dart';
// import 'package:fusion/Components/side_drawer.dart';

class HostelDues extends StatefulWidget {
  @override
  _HostelDuesState createState() => _HostelDuesState();
}

class _HostelDuesState extends State<HostelDues> {
  @override
  Widget build(BuildContext context) {
    // final AcademicData data =
    //     ModalRoute.of(context)!.settings.arguments as AcademicData;
    return Scaffold(
      body: Container(
        alignment: Alignment.center,
        padding: EdgeInsets.all(16),
        child: Text(
          'work in progress',
        ),
      ),
    );
  }
}
